var headerLink = $("#headerLink");
var apply = $(".apply");
var float = $(".index");
console.log(apply);
apply.mouseup(function () {
    // float.style.visibility = 'visible';
    console.log('11111');
});
apply.mouseout(function () {
    // float.style.visibility = 'hidden';
});